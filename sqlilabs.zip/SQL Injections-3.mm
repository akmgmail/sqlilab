<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1324136400104" ID="ID_1494913344" MODIFIED="1412376747822" TEXT="SQL Injections-Page-4">
<node CREATED="1324136425237" HGAP="-20" ID="ID_903641389" MODIFIED="1412377159425" POSITION="right" TEXT="Less-55" VSHIFT="25">
<icon BUILTIN="pencil"/>
<node CREATED="1324136506469" ID="ID_456038241" MODIFIED="1412415595300" TEXT="GET - challenge - Union- 14 queries allowed - Variation 2" VSHIFT="12">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136501788" HGAP="-1" ID="ID_1198941000" MODIFIED="1412377287375" POSITION="right" TEXT="Less - 57" VSHIFT="7">
<icon BUILTIN="pencil"/>
<node CREATED="1324136690771" HGAP="15" ID="ID_85068748" MODIFIED="1412415625617" TEXT="GET - challenge - Union- 14 queries allowed - Variation 4" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136429162" HGAP="-14" ID="ID_194436165" MODIFIED="1412376774656" POSITION="left" TEXT="Less-54" VSHIFT="420">
<icon BUILTIN="pencil"/>
<node CREATED="1324137533985" ID="ID_1551007752" MODIFIED="1412415586423" TEXT="GET - challenge - Union- 10 queries allowed - Variation 1" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324136441860" HGAP="-1" ID="ID_351889515" MODIFIED="1412376785009" POSITION="left" STYLE="fork" TEXT="Less - 56" VSHIFT="5">
<icon BUILTIN="pencil"/>
<node CREATED="1324137615576" HGAP="17" ID="ID_201265776" MODIFIED="1412415653702" TEXT="GET - challenge - Union- 14 queries allowed - variation 3" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137319383" HGAP="11" ID="ID_853573586" MODIFIED="1412377386210" POSITION="right" TEXT="Less - 59" VSHIFT="-3">
<icon BUILTIN="pencil"/>
<node CREATED="1324137333904" HGAP="17" ID="ID_429405468" MODIFIED="1412377401887" TEXT="GET - challenge - Double Query- 5 queries allowed - Variation 2" VSHIFT="14">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137466548" HGAP="3" ID="ID_117543297" MODIFIED="1412377304548" POSITION="left" TEXT="Less - 58" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1324137630177" ID="ID_831348399" MODIFIED="1412377352950" TEXT="GET - challenge - Double Query- 5 queries allowed - Variation 1" VSHIFT="16">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137707627" HGAP="15" ID="ID_1410936587" MODIFIED="1412377411698" POSITION="right" TEXT="Less - 61" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1324137874201" HGAP="21" ID="ID_1403477223" MODIFIED="1412377423272" TEXT="GET - challenge - Double Query- 5 queries allowed - Variation 4" VSHIFT="18">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137711332" HGAP="12" ID="ID_824569291" MODIFIED="1412376811411" POSITION="left" TEXT="Less - 60" VSHIFT="-3">
<icon BUILTIN="pencil"/>
<node CREATED="1324137896185" HGAP="16" ID="ID_1830668257" MODIFIED="1412415674901" TEXT="GET - challenge - Double Query- 5 queries allowed - Variation 3" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137714364" HGAP="16" ID="ID_188847598" MODIFIED="1412377436739" POSITION="right" TEXT="Less - 63" VSHIFT="4">
<icon BUILTIN="pencil"/>
<node CREATED="1324137878394" HGAP="18" ID="ID_1523865604" MODIFIED="1412377484064" TEXT="GET - challenge - Blind - 130 queries allowed - Variation 2" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1324137717348" HGAP="14" ID="ID_1523381996" MODIFIED="1412376819389" POSITION="left" TEXT="Less - 62" VSHIFT="-13">
<icon BUILTIN="pencil"/>
<node CREATED="1324137890129" HGAP="16" ID="ID_1287016606" MODIFIED="1412376933802" TEXT="GET - challenge - Blind - 130 queries allowed - variation 1" VSHIFT="17">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259455429" HGAP="14" ID="ID_466917223" MODIFIED="1412377576044" POSITION="right" TEXT="Less - 65" VSHIFT="8">
<icon BUILTIN="pencil"/>
<node CREATED="1337259473888" ID="ID_962658043" MODIFIED="1412377497139" TEXT="GET - challenge - Blind - 130 queries allowed - Variation 4" VSHIFT="21">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259571346" HGAP="13" ID="ID_808975697" MODIFIED="1412376831485" POSITION="left" TEXT="Less - 64" VSHIFT="-9">
<icon BUILTIN="pencil"/>
<node CREATED="1337259649440" HGAP="19" ID="ID_190240143" MODIFIED="1412376963103" TEXT="GET - challenge - Blind - 130 queries allowed - variation 3" VSHIFT="13">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259743007" HGAP="25" ID="ID_889999997" MODIFIED="1412377584437" POSITION="right" TEXT="Less - 67" VSHIFT="2">
<icon BUILTIN="pencil"/>
<node CREATED="1337260036723" HGAP="23" ID="ID_470682976" MODIFIED="1412377525707" TEXT="GET - challenge - Blind - 3 queries allowed - Variation 2" VSHIFT="21">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259745713" HGAP="10" ID="ID_1208232472" MODIFIED="1412376979841" POSITION="left" TEXT="Less - 66" VSHIFT="-28">
<icon BUILTIN="pencil"/>
<node CREATED="1337260017152" HGAP="22" ID="ID_778159028" MODIFIED="1412377132001" TEXT="GET - challenge - Blind - 3 queries allowed -Variation 1" VSHIFT="13">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259760351" HGAP="9" ID="ID_1236630160" MODIFIED="1412377594508" POSITION="right" TEXT="Less - 69" VSHIFT="22">
<icon BUILTIN="pencil"/>
<node CREATED="1337260042429" ID="ID_1831469301" MODIFIED="1412377616688" TEXT="GET - challenge - Blind - 3 queries allowed - Variation 4" VSHIFT="16">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259762765" HGAP="3" ID="ID_1521023455" MODIFIED="1412377083459" POSITION="left" TEXT="Less - 68" VSHIFT="-14">
<icon BUILTIN="pencil"/>
<node CREATED="1337260056500" HGAP="18" ID="ID_1620579356" MODIFIED="1412377120509" TEXT="GET - challenge - Blind - 3 queries allowed - Variation 3" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259768974" HGAP="12" ID="ID_1264770325" MODIFIED="1412377728953" POSITION="right" TEXT="Less - 71" VSHIFT="12">
<icon BUILTIN="pencil"/>
<node CREATED="1337260049111" HGAP="22" ID="ID_1399680041" MODIFIED="1412377855249" TEXT="POST - challenge - error - 10 queries allowed - Variation 2" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337259771723" HGAP="-3" ID="ID_371433913" MODIFIED="1412377704483" POSITION="left" TEXT="Less - 70" VSHIFT="-19">
<icon BUILTIN="pencil"/>
<node CREATED="1337260061967" HGAP="23" ID="ID_1507876679" MODIFIED="1412377836727" TEXT="POST - challenge - error - 10 queries allowed - Variation 1" VSHIFT="15">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286635272" HGAP="8" ID="ID_1025670211" MODIFIED="1412377738714" POSITION="right" TEXT="Less-73" VSHIFT="20">
<icon BUILTIN="pencil"/>
<node CREATED="1337286752435" ID="ID_586679887" MODIFIED="1412377864621" TEXT="POST - challenge - error - 10 queries allowed - Variation 4" VSHIFT="20">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286664875" HGAP="-16" ID="ID_622646021" MODIFIED="1412377711506" POSITION="left" TEXT="Less-72" VSHIFT="-1">
<icon BUILTIN="pencil"/>
<node CREATED="1337286733038" HGAP="19" ID="ID_1658696559" MODIFIED="1412377847371" TEXT="POST - challenge - error - 10 queries allowed - Variation 3" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286811307" HGAP="-13" ID="ID_675480068" MODIFIED="1412377752450" POSITION="right" TEXT="Less-75" VSHIFT="-184">
<icon BUILTIN="pencil"/>
<node CREATED="1337287084942" HGAP="21" ID="ID_471107631" MODIFIED="1412377913654" TEXT="POST - challenge - Blind - 10 queries allowed - Variation 2" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
<node CREATED="1337286920172" HGAP="-35" ID="ID_38136745" MODIFIED="1412377719935" POSITION="left" TEXT="Less-74" VSHIFT="-500">
<icon BUILTIN="pencil"/>
<node CREATED="1337287063065" HGAP="16" ID="ID_58695417" MODIFIED="1412377899421" TEXT="POST - challenge - Blind - 3 queries allowed - Variation 1" VSHIFT="18">
<icon BUILTIN="penguin"/>
</node>
</node>
</node>
</map>
